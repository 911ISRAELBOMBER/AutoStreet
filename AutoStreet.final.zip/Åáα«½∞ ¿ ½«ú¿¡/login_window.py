import sys
import bcrypt
from PyQt6.QtWidgets import QApplication, QWidget, QVBoxLayout, QLabel, QLineEdit, QPushButton, QMessageBox
from models import User
from db import session

class LoginWindow(QWidget):
    
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Вход")
        self.setGeometry(100, 100, 300, 200)
        
        # Установка стиля
        self.setStyleSheet("background-color: #ffcccc; color: #990000;")
        
        layout = QVBoxLayout()
        
        self.email_input = QLineEdit(self)
        self.email_input.setPlaceholderText("Введите ваш email")
        layout.addWidget(self.email_input)
        
        self.password_input = QLineEdit(self)
        self.password_input.setPlaceholderText("Введите ваш пароль")
        self.password_input.setEchoMode(QLineEdit.EchoMode.Password)
        layout.addWidget(self.password_input)
        
        self.login_button = QPushButton("Войти", self)
        self.login_button.clicked.connect(self.login_user)
        layout.addWidget(self.login_button)
        
        self.setLayout(layout)

    def login_user(self):
        email = self.email_input.text().strip()  # Удаляем пробелы
        password = self.password_input.text().strip()  # Удаляем пробелы
        
        # Проверка на пустые поля
        if not email or not password:
            QMessageBox.warning(self, "Ошибка", "Пожалуйста, введите email и пароль.")
            return
        
        # Поиск пользователя по email
        user = session.query(User).filter_by(email=email).first()
        
        if user:
            # Проверка пароля
            if bcrypt.checkpw(password.encode('utf-8'), user.password_hash.encode('utf-8')):
                QMessageBox.information(self, "Успех", "Успешный вход!")
                # Здесь можно добавить логику для перехода в основное приложение
            else:
                QMessageBox.warning(self, "Ошибка", "Неверный пароль.")
        else:
            QMessageBox.warning(self, "Ошибка", "Пользователь не найден.")

if __name__ == "__main__":
    app = QApplication(sys.argv)

    login_window = LoginWindow()
    login_window.show()
    
    sys.exit(app.exec())