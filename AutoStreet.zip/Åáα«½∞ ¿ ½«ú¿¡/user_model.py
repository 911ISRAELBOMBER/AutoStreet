from sqlalchemy import Column, Integer, String, Boolean, ForeignKey, DateTime, Numeric, func
from sqlalchemy.orm import relationship
from db import Base

class User(Base):
    __tablename__ = 'users'
    __table_args__ = {'schema': 'avto'}
    id = Column(Integer, primary_key=True)
    email = Column(String(100), unique=True, nullable=False)
    password_hash = Column(String(255), nullable=False)
    phone = Column(String(20), nullable=False)
    is_admin = Column(Boolean, default=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())