import sys
import bcrypt
from PyQt6.QtWidgets import QApplication, QWidget, QVBoxLayout, QLabel, QLineEdit, QPushButton, QMessageBox
from models import User
from db import session

class RegistrationWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Регистрация")
        self.setGeometry(100, 100, 300, 250)
        
        # Установка стиля
        self.setStyleSheet("background-color: #ffcccc; color: #990000;")
        
        layout = QVBoxLayout()
        
        self.email_input = QLineEdit(self)
        self.email_input.setPlaceholderText("Введите ваш email")
        layout.addWidget(self.email_input)
        
        self.password_input = QLineEdit(self)
        self.password_input.setPlaceholderText("Введите ваш пароль")
        self.password_input.setEchoMode(QLineEdit.EchoMode.Password)
        layout.addWidget(self.password_input)

        self.phone_input = QLineEdit(self)
        self.phone_input.setPlaceholderText("Введите ваш номер телефона")
        layout.addWidget(self.phone_input)
        
        self.register_button = QPushButton("Зарегистрироваться", self)
        self.register_button.clicked.connect(self.register_user)
        layout.addWidget(self.register_button)
        
        self.setLayout(layout)

    def register_user(self):
        email = self.email_input.text()
        password = self.password_input.text()
        phone = self.phone_input.text()
        
        try:
            # Хэширование пароля
            password_hash = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())
            
            # Создание нового пользователя
            new_user = User(email=email, password_hash=password_hash.decode('utf-8'), phone=phone)
            
            # Добавление пользователя в сессию и коммит
            session.add(new_user)
            session.commit()
            
            QMessageBox.information(self, "Успех", "Пользователь зарегистрирован успешно!")
        except Exception as e:
            session.rollback()
            QMessageBox.critical(self, "Ошибка", f"Не удалось зарегистрировать пользователя: {e}")
        
if __name__ == "__main__":
    app = QApplication(sys.argv)
    
    try:
        # Для запуска окна регистрации
        registration_window = RegistrationWindow()
        registration_window.show()
        
        sys.exit(app.exec())
    except Exception as e:
        print(f"Произошла ошибка: {e}")