import sys
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QPushButton, QLabel, 
    QStackedWidget, QComboBox, QGridLayout, QLineEdit, QMessageBox, QHBoxLayout, QListWidget, QListWidgetItem
)
from PyQt6.QtCore import pyqtSignal
from passlib.context import CryptContext
from sqlalchemy.exc import IntegrityError
from db import Session
from models import User, Product, Order
import bcrypt
from sqlalchemy.orm import sessionmaker
from db import engine
from sqlalchemy.orm import sessionmaker
from models import Order, Payment 

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Магазин автозапчастей AutoStreet")
        self.setGeometry(100, 100, 800, 600)

        self.central_widget = QStackedWidget()
        self.setCentralWidget(self.central_widget)

        # Создаем окна авторизации и регистрации
        self.auth_window = LoginWindow(self)
        self.register_window = RegisterWindow(self.central_widget)
        
        # Создаем окна основного приложения
        self.main_menu = MainMenu(self.central_widget)
        self.catalog = CatalogWindow(self.central_widget)
        self.cart = CartWindow(self.central_widget)
        self.order = OrderWindow(self.central_widget)

        # Добавляем все окна в стек
        self.central_widget.addWidget(self.auth_window)
        self.central_widget.addWidget(self.register_window)
        self.central_widget.addWidget(self.main_menu)
        self.central_widget.addWidget(self.catalog)
        self.central_widget.addWidget(self.cart)
        self.central_widget.addWidget(self.order)

        # Связываем сигналы
        self.auth_window.switch_to_register.connect(self.show_register)
        self.register_window.switch_to_auth.connect(self.show_auth)
        self.auth_window.auth_successful.connect(self.show_main_app)
        
        # Показываем окно авторизации сначала
        self.central_widget.setCurrentWidget(self.auth_window)

    def show_auth(self):
        self.central_widget.setCurrentWidget(self.auth_window)
    
    def show_register(self):
        self.central_widget.setCurrentWidget(self.register_window)
    
    def show_main_app(self):
        self.central_widget.setCurrentWidget(self.main_menu)

class LoginWindow(QWidget):
    switch_to_register = pyqtSignal()  # Сигнал для переключения на окно регистрации
    auth_successful = pyqtSignal()      # Сигнал для успешного входа

    def __init__(self, main_window):
        super().__init__()
        self.main_window = main_window
        self.setWindowTitle("Вход")
        self.setGeometry(100, 100, 300, 200)
        
        # Установка стиля
        self.setStyleSheet("background-color: #ffcccc; color: #990000;")
        
        layout = QVBoxLayout()
        
        self.email_input = QLineEdit(self)
        self.email_input.setPlaceholderText("Введите ваш email")
        layout.addWidget(self.email_input)
        
        self.password_input = QLineEdit(self)
        self.password_input.setPlaceholderText("Введите ваш пароль")
        self.password_input.setEchoMode(QLineEdit.EchoMode.Password)
        layout.addWidget(self.password_input)
        
        self.login_button = QPushButton("Войти", self)
        self.login_button.clicked.connect(self.login_user)
        layout.addWidget(self.login_button)

        # Кнопка для перехода на регистрацию
        self.register_button = QPushButton("Зарегистрироваться", self)
        self.register_button.clicked.connect(self.switch_to_registration)
        layout.addWidget(self.register_button)
        
        self.setLayout(layout)

    def login_user(self):
        email = self.email_input.text().strip()
        password = self.password_input.text().strip()
        
        if not email or not password:
            QMessageBox.warning(self, "Ошибка", "Пожалуйста, введите email и пароль.")
            return
        
        # Создаем сессию
        Session = sessionmaker(bind=engine)
        session = Session()

        try:
            user = session.query(User).filter_by(email=email).first()
            
            if user:
                if bcrypt.checkpw(password.encode('utf-8'), user.password_hash.encode('utf-8')):
                    QMessageBox.information(self, "Успех", "Успешный вход!")
                    self.auth_successful.emit()  # Сигнал для перехода в основное приложение
                else:
                    QMessageBox.warning(self, "Ошибка", "Неверный пароль.")
            else:
                QMessageBox.warning(self, "Ошибка", "Пользователь не найден.")
        finally:
            session.close()  # Закрываем сессию

    def switch_to_registration(self):
        self.switch_to_register.emit()  # Вызываем сигнал для переключения на окно регистрации

class RegisterWindow(QWidget):
    switch_to_auth = pyqtSignal()

    def __init__(self, central_widget):
        super().__init__()
        self.central_widget = central_widget
        layout = QVBoxLayout()

        self.email_input = QLineEdit(self)
        self.email_input.setPlaceholderText("Введите ваш email")
        layout.addWidget(self.email_input)

        self.password_input = QLineEdit(self)
        self.password_input.setPlaceholderText("Введите ваш пароль")
        self.password_input.setEchoMode(QLineEdit.EchoMode.Password)
        layout.addWidget(self.password_input)

        self.phone_input = QLineEdit(self)
        self.phone_input.setPlaceholderText("Введите ваш номер телефона")
        layout.addWidget(self.phone_input)

        register_button = QPushButton("Зарегистрироваться", self)
        register_button.clicked.connect(self.register_user)
        layout.addWidget(register_button)

        back_button = QPushButton("Назад", self)
        back_button.clicked.connect(self.switch_to_auth.emit)
        layout.addWidget(back_button)

        self.setLayout(layout)
        self.setStyleSheet("background-color: #ffcccc; color: #990000;")

    def register_user(self):
        email = self.email_input.text()
        password = self.password_input.text()
        phone = self.phone_input.text()

        hashed_password = CryptContext(schemes=["bcrypt"]).hash(password)
        new_user = User(email=email, password_hash=hashed_password, phone=phone)

        # Создаем сессию
        session = Session()  # Создаем экземпляр сессии

        try:
            session.add(new_user)
            session.commit()
            QMessageBox.information(self, "Успех", "Пользователь зарегистрирован успешно!")
            self.switch_to_auth.emit()  # Переключаемся на окно авторизации
        except IntegrityError:
            session.rollback()
            QMessageBox.warning(self, "Ошибка", "Пользователь с таким email уже существует.")
        finally:
            session.close()  # Закрываем сессию

class MainMenu(QWidget):
    def __init__(self, central_widget):
        super().__init__()
        self.central_widget = central_widget
        layout = QVBoxLayout()

        title_label = QLabel("Добро пожаловать в Магазин автозапчастей! AutoStreet", self)
        title_label.setStyleSheet("font-size: 24px; font-weight: bold; color: #990000;")
        layout.addWidget(title_label)

        description_label = QLabel(
            "Здесь вы можете найти все необходимые автозапчасти для вашего автомобиля.\n"
            "Просматривайте каталог, добавляйте товары в корзину и оформляйте заказы с легкостью!",
            self
        )
        description_label.setWordWrap(True)
        description_label.setStyleSheet("font-size: 16px; color: #660000;")
        layout.addWidget(description_label)

        catalog_button = QPushButton("Перейти в каталог", self)
        catalog_button.clicked.connect(self.go_to_catalog)
        layout.addWidget(catalog_button)

        cart_button = QPushButton("Перейти в корзину", self)
        cart_button.clicked.connect(self.go_to_cart)
        layout.addWidget(cart_button)

        order_button = QPushButton("Оформить заказ", self)
        order_button.clicked.connect(self.go_to_order)
        layout.addWidget(order_button)

        self.setLayout(layout)
        self.setStyleSheet("background-color: #ffcccc; color: #990000;")

    def go_to_catalog(self):
        self.central_widget.setCurrentWidget(self.central_widget.parent().catalog)

    def go_to_cart(self):
        self.central_widget.setCurrentWidget(self.central_widget.parent().cart)

    def go_to_order(self):
        self.central_widget.setCurrentWidget(self.central_widget.parent().order)

class CatalogWindow(QWidget):
    def __init__(self, central_widget):
        super().__init__()
        self.central_widget = central_widget
        layout = QVBoxLayout()

        title_label = QLabel("Каталог автозапчастей", self)
        title_label.setStyleSheet("font-size: 24px; font-weight: bold; color: #990000;")
        layout.addWidget(title_label)

        category_label = QLabel("Выберите категорию товара:", self)
        layout.addWidget(category_label)

        self.category_combo = QComboBox(self)
        self.category_combo.addItems(["Все товары", "Двигатели", "Тормоза", "Подвеска", "Электрика"])
        layout.addWidget(self.category_combo)

        filter_button = QPushButton("Применить фильтр", self)
        filter_button.clicked.connect(self.apply_filter)
        layout.addWidget(filter_button)

        self.product_grid = QGridLayout()
        layout.addLayout(self.product_grid)

        self.populate_products()  # Заполнение продуктов из БД

        back_button = QPushButton("Назад", self)
        back_button.clicked.connect(self.go_back)
        layout.addWidget(back_button)

        self.setLayout(layout)
        self.setStyleSheet("background-color: #ffcccc; color: #990000;")

    def populate_products(self):
        # Создаем сессию
        session = Session()  # Создаем экземпляр сессии

        try:
            # Запрашиваем все продукты из базы данных
            products = session.query(Product).all()

            for i, product in enumerate(products):  
                product_widget = QWidget()
                product_layout = QVBoxLayout()
                
                name_label = QLabel(product.name)
                price_label = QLabel(f"{product.price} руб.")
                add_button = QPushButton("Добавить в корзину")
                
                # Передаем данные о товаре в корзину
                add_button.clicked.connect(lambda _, p=product: self.add_to_cart(p))
                
                product_layout.addWidget(name_label)
                product_layout.addWidget(price_label)
                product_layout.addWidget(add_button)
                product_widget.setLayout(product_layout)
                
                self.product_grid.addWidget(product_widget, i // 3, i % 3)
        finally:
            session.close()  # Закрываем сессию

    def add_to_cart(self, product):
        self.central_widget.parent().cart.add_to_cart(
            product.id,
            product.name,
            product.price
        )
        QMessageBox.information(self, "Успех", "Товар добавлен в корзину!")

    def apply_filter(self):
        selected_category = self.category_combo.currentText()
        print(f"Применен фильтр: {selected_category}")

    def go_back(self):
        self.central_widget.setCurrentWidget(self.central_widget.parent().main_menu)

class CartWindow(QWidget):
    def __init__(self, central_widget):
        super().__init__()
        self.central_widget = central_widget
        self.cart_items = []  # Список товаров в корзине
        self.init_ui()
    
    def init_ui(self):
        self.setWindowTitle("Корзина")
        self.setGeometry(100, 100, 600, 400)
        
        layout = QVBoxLayout()
        
        # Заголовок
        title_label = QLabel("Ваша корзина", self)
        title_label.setStyleSheet("font-size: 20px; font-weight: bold;")
        layout.addWidget(title_label)
        
        # Список товаров
        self.cart_list = QListWidget(self)
        self.cart_list.setStyleSheet("""
            QListWidget {
                background-color: #fff;
                border: 1px solid #ddd;
                font-size: 14px;
            }
            QListWidget::item {
                padding: 8px;
                border-bottom: 1px solid #eee;
            }
        """)
        layout.addWidget(self.cart_list)
        
        # Общая сумма
        self.total_label = QLabel("Итого: 0 руб.", self)
        self.total_label.setStyleSheet("font-size: 18px; font-weight: bold;")
        layout.addWidget(self.total_label)

        # Кнопки управления
        button_layout = QHBoxLayout()
        
        self.clear_button = QPushButton("Очистить корзину", self)
        self.clear_button.clicked.connect(self.clear_cart)
        self.clear_button.setStyleSheet("background-color: #ffcccc; color: #990000;")
        button_layout.addWidget(self.clear_button)
        
        self.checkout_button = QPushButton("Оформить заказ", self)
        self.checkout_button.clicked.connect(self.checkout)
        self.checkout_button.setStyleSheet("background-color: #ffcccc; color: #990000;")
        button_layout.addWidget(self.checkout_button)
        
        layout.addLayout(button_layout)
        
        # Кнопка назад
        back_button = QPushButton("Назад", self)
        back_button.clicked.connect(self.go_back)
        layout.addWidget(back_button)
        
        self.setLayout(layout)
        self.update_cart_display()
    
    def add_to_cart(self, product_id, name, price, quantity=1):
        """Добавление товара в корзину"""
        for item in self.cart_items:
            if item['product_id'] == product_id:
                item['quantity'] += quantity
                self.update_cart_display()
                return
        
        self.cart_items.append({
            'product_id': product_id,
            'name': name,
            'price': price,
            'quantity': quantity
        })
        self.update_cart_display()
    
    def remove_from_cart(self, product_id):
        """Удаление товара из корзины"""
        self.cart_items = [item for item in self.cart_items if item['product_id'] != product_id]
        self.update_cart_display()
    
    def clear_cart(self):
        """Очистка корзины"""
        self.cart_items = []
        self.update_cart_display()
    
    def update_cart_display(self):
        """Обновление отображения корзины"""
        self.cart_list.clear()
        total = 0
        
        for item in self.cart_items:
            item_total = item['price'] * item['quantity']
            total += item_total
            
            list_item = QListWidgetItem(
                f"{item['name']} - {item['price']} руб. x {item['quantity']} = {item_total} руб."
            )
            self.cart_list.addItem(list_item)
        
        self.total_label.setText(f"Итого: {total} руб.")
    
    def checkout(self):
        address = self.address_input.text()
        payment_method = self.payment_method_combo.currentText()

        if not address:
            QMessageBox.warning(self, "Ошибка", "Пожалуйста, введите адрес доставки.")
            return

        # Создаем сессию
        Session = sessionmaker(bind=engine)
        session = Session()

        try:
            # Создание нового заказа
            new_order = Order(
                user_id=self.current_user_id,  # Убедитесь, что у вас есть текущий ID пользователя
                status='Ожидает оплаты',  # Устанавливаем статус заказа
                total=self.calculate_total(),  # Предполагается, что у вас есть метод для расчета общей суммы
                address=address
            )
            session.add(new_order)
            session.commit()  # Сохраняем заказ, чтобы получить его ID

            # Создание записи о платеже
            new_payment = Payment(
                order_id=new_order.id,
                amount=new_order.total,  # Используем общую сумму заказа
                method=payment_method,
                status='Успешно'  # Или другой статус, в зависимости от логики
            )
            session.add(new_payment)
            session.commit()  # Сохраняем платеж

            QMessageBox.information(self, "Успех", f"Заказ оформлен!\nАдрес: {address}\nСпособ оплаты: {payment_method}")

            # Очистка полей после оформления заказа
            self.address_input.clear()
            self.payment_method_combo.setCurrentIndex(0)

        except Exception as e:
            session.rollback()  # Откат транзакции в случае ошибки
            QMessageBox.critical(self, "Ошибка", f"Не удалось оформить заказ: {str(e)}")
        finally:
            session.close()  # Закрываем сессию

class OrderWindow(QWidget):
    def __init__(self, central_widget):
        super().__init__()
        self.central_widget = central_widget
        layout = QVBoxLayout()

        # Заголовок
        title_label = QLabel("Оформление заказа", self)
        title_label.setStyleSheet("font-size: 24px; font-weight: bold; color: #990000;")
        layout.addWidget(title_label)

        # Поле для ввода адреса
        self.address_input = QLineEdit(self)
        self.address_input.setPlaceholderText("Введите адрес доставки")
        layout.addWidget(self.address_input)

        # Выбор способа оплаты
        self.payment_method_combo = QComboBox(self)
        self.payment_method_combo.addItems(["Кредитная карта", "Дебетовая карта", "Наличные", "Электронный кошелек"])
        layout.addWidget(self.payment_method_combo)

        # Кнопка для оформления заказа
        checkout_button = QPushButton("Оформить заказ", self)
        checkout_button.clicked.connect(self.checkout)
        layout.addWidget(checkout_button)

        # Кнопка назад
        back_button = QPushButton("Назад", self)
        back_button.clicked.connect(self.go_back)
        layout.addWidget(back_button)

        self.setLayout(layout)
        self.setStyleSheet("background-color: #ffcccc; color: #990000;")

    def checkout(self):
        address = self.address_input.text()
        payment_method = self.payment_method_combo.currentText()

        if not address:
            QMessageBox.warning(self, "Ошибка", "Пожалуйста, введите адрес доставки.")
            return

        # Создаем сессию
        Session = sessionmaker(bind=engine)
        session = Session()

        try:
            # Создание нового заказа
            new_order = Order(
                user_id=self.get_current_user_id(),  # Получите текущий ID пользователя
                status='Ожидает оплаты',  # Установите статус заказа
                total=self.calculate_total(),  # Предполагается, что у вас есть метод для расчета общей суммы
                address=address
            )
            session.add(new_order)
            session.commit()  # Сохраняем заказ, чтобы получить его ID

            # Создание записи о платеже
            new_payment = Payment(
                order_id=new_order.id,
                amount=new_order.total,  # Используем общую сумму заказа
                method=payment_method,
                status='Успешно'  # Или другой статус, в зависимости от логики
            )
            session.add(new_payment)
            session.commit()  # Сохраняем платеж

            QMessageBox.information(self, "Успех", f"Заказ оформлен!\nАдрес: {address}\nСпособ оплаты: {payment_method}")

            # Очистка полей после оформления заказа
            self.address_input.clear()
            self.payment_method_combo.setCurrentIndex(0)

        except Exception as e:
            session.rollback()  # Откат транзакции в случае ошибки
            QMessageBox.critical(self, "Ошибка", f"Не удалось оформить заказ: {str(e)}")
        finally:
            session.close()  # Закрываем сессию

    def go_back(self):
        self.central_widget.setCurrentWidget(self.central_widget.parent().main_menu)

    def get_current_user_id(self):
        # Здесь должна быть логика для получения текущего ID пользователя
        # Например, если у вас есть класс User с атрибутом id
        return 1  # Замените на реальный ID пользователя

    def calculate_total(self):
        # Здесь должна быть логика для расчета общей суммы заказа
        return 100.00  # Замените на реальную логику расчета

class ProductDetailWindow(QWidget):
    def __init__(self, product, central_widget):
        super().__init__()
        self.central_widget = central_widget
        layout = QVBoxLayout()

        title_label = QLabel(product.name, self)
        title_label.setStyleSheet("font-size: 24px; font-weight: bold; color: #990000;")
        layout.addWidget(title_label)

        price_label = QLabel(f"Цена: {product.price} руб.", self)
        price_label.setStyleSheet("font-size: 20px; color: #660000;")
        layout.addWidget(price_label)

        add_to_cart_button = QPushButton("Добавить в корзину", self)
        add_to_cart_button.clicked.connect(lambda: self.add_to_cart(product))
        layout.addWidget(add_to_cart_button)

        self.setLayout(layout)
        self.setStyleSheet("background-color: #ffcccc; color: #990000;")

    def add_to_cart(self, product):
        print(f"{product.name} добавлен в корзину!")

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())