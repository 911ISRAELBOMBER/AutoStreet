from sqlalchemy import Column, Integer, String, Boolean, ForeignKey, DateTime, Numeric, func
from sqlalchemy.orm import relationship
from db import Base

# еще раз ты блять будешь тупо списывать я тебе хуй потом помогу
from sqlalchemy import Column, Integer, String, Boolean, ForeignKey, DateTime, Numeric, func
from sqlalchemy.orm import relationship
from db import Base

class User(Base):
    __tablename__ = 'users'
    
    id = Column(Integer, primary_key=True)
    email = Column(String(100), unique=True, nullable=False)
    password_hash = Column(String(255), nullable=False)
    phone = Column(String(20), nullable=False)
    is_admin = Column(Boolean, default=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    
    # Исправленные отношения:
    carts = relationship("Cart", back_populates="user")
    orders = relationship("Order", back_populates="user")

class GoodsCategory(Base):
    __tablename__ = 'goods_categories'
    
    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False)
    description = Column(String(255), nullable=False)
    
    # Исправленное отношение:
    products = relationship("Product", back_populates="category")

class Manufacturer(Base):
    __tablename__ = 'manufacturers'
    
    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False)
    logo_url = Column(String(255), nullable=False)
    description = Column(String(255), nullable=False)
    
    # Исправленное отношение:
    products = relationship("Product", back_populates="manufacturer")

class Product(Base):
    __tablename__ = 'products'
    
    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False)
    description = Column(String(255), nullable=False)
    price = Column(Numeric(10, 2), nullable=False)
    stock_quantity = Column(Integer, nullable=False)
    category_id = Column(Integer, ForeignKey('goods_categories.id'))
    manufacturer_id = Column(Integer, ForeignKey('manufacturers.id'))
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    
    # Исправленные отношения:
    category = relationship("GoodsCategory", back_populates="products")
    manufacturer = relationship("Manufacturer", back_populates="products")
    images = relationship("Image", back_populates="product")
    carts = relationship("Cart", back_populates="product")

class Cart(Base):
    __tablename__ = 'carts'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'))
    product_id = Column(Integer, ForeignKey('products.id'))
    quantity = Column(Integer, nullable=False)
    
    # Исправленные отношения:
    user = relationship("User", back_populates="carts")
    product = relationship("Product", back_populates="carts")

class Image(Base):
    __tablename__ = 'images'
    
    id = Column(Integer, primary_key=True)
    product_id = Column(Integer, ForeignKey('products.id'))
    image_url = Column(String(255), nullable=False)
    is_main = Column(Boolean, nullable=False)
    
    # Исправленное отношение:
    product = relationship("Product", back_populates="images")

class Order(Base):
    __tablename__ = 'orders'
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'))
    status = Column(String(50), nullable=False)
    total = Column(Numeric(10, 2), nullable=False)
    address = Column(String(100), nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    
    # Исправленные отношения:
    user = relationship("User", back_populates="orders")
    deliveries = relationship("Delivery", back_populates="order")
    payments = relationship("Payment", back_populates="order")

class Delivery(Base):
    __tablename__ = 'deliveries'
    
    id = Column(Integer, primary_key=True)
    order_id = Column(Integer, ForeignKey('orders.id'))
    tracking_number = Column(String(50), nullable=False)
    status = Column(String(50), nullable=False)
    delivery_method = Column(String(50), nullable=False)
    
    # Исправленное отношение:
    order = relationship("Order", back_populates="deliveries")

class Payment(Base):
    __tablename__ = 'payments'
    
    id = Column(Integer, primary_key=True)
    order_id = Column(Integer, ForeignKey('orders.id'))
    amount = Column(Numeric(10, 2), nullable=False)
    method = Column(String(50), nullable=False)
    status = Column(String(50), nullable=False)
    transaction_id = Column(String(100))
    payment_date = Column(DateTime(timezone=True), server_default=func.now())
    
    # Исправленное отношение:
    order = relationship("Order", back_populates="payments")